
# Web App – Analisi Portafogli Clienti (Giancarlo Raimondi)

Questa applicazione permette di caricare un portafoglio Excel e visualizzarne un'anteprima.

## Come si usa su Streamlit Cloud:

1. Crea un nuovo repository GitHub chiamato `analisi-portafoglio-ai`
2. Carica in quel repo i 3 file: `main.py`, `requirements.txt`, `README.md`
3. Vai su [https://share.streamlit.io](https://share.streamlit.io) e clicca su “Create app”
4. Collega il tuo repo GitHub e seleziona `main.py` come file da eseguire
5. Premi “Deploy” e apri l'app dal link che ti verrà dato

✅ Tutto sarà accessibile anche da iPad.
